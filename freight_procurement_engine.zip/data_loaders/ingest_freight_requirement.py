import io
import json
import os
import urllib.request
from typing import Dict, Any

if 'data_loader' not in globals():
    from mage_ai.data_preparation.decorators import data_loader
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test

GROQ_API_KEY = os.environ.get('GROQ_API_KEY', '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')

def call_groq_llm(prompt: str, model: str = 'openai/gpt-oss-20b') -> dict:
    url = 'https://api.groq.com/openai/v1/chat/completions'
    headers = {
        'Authorization': f'Bearer {GROQ_API_KEY}',
        'Content-Type': 'application/json',
        'User-Agent': 'MageAI-FreightEngine/1.0'
    }
    payload = {
        'model': model,
        'messages': [
            {'role': 'system', 'content': 'You are a senior freight requirement normalization AI. Output STRICT JSON only.'},
            {'role': 'user', 'content': prompt}
        ],
        'response_format': {'type': 'json_object'},
        'temperature': 0.1
    }
    req = urllib.request.Request(url, data=json.dumps(payload).encode('utf-8'), headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            data = json.loads(resp.read().decode('utf-8'))
            return json.loads(data['choices'][0]['message']['content'])
    except Exception as e:
        return {
            'transport_modes_needed': ['road', 'sea'],
            'is_hazmat': True,
            'requires_temperature_control': True,
            'is_oversized': False,
            'requires_special_handling': True,
            'estimated_transit_days': 27,
            'origin_country_code': 'NL',
            'destination_country_code': 'CN',
            'fallback_used': True,
            'error': str(e)
        }

@data_loader
def load_freight_requirement(*args, **kwargs) -> Dict[str, Any]:
    requirement = {
        "requirement_id": "REQ-2026-EU-ASIA-8942",
        "origin": "Shipper Warehouse, Eindhoven, NL",
        "origin_port": "Port of Rotterdam (Maasvlakte), NL",
        "destination": "Shanghai Distribution Hub, Pudong, CN",
        "destination_port": "Port of Shanghai (Yangshan Deepwater), CN",
        "cargo_description": "Lithium-Ion Energy Storage Modules (Class 9 Hazmat, Temp-Controlled 15-25°C)",
        "cargo_weight_kg": 14500,
        "cargo_volume_cbm": 38.4,
        "cargo_dimensions_cm": {"length": 600, "width": 240, "height": 260},
        "temperature_required": "15-25°C",
        "hazmat_class": "Class 9 UN3480",
        "delivery_deadline": "2026-11-25",
        "incoterms": "CIF",
        "insurance_required": True,
        "expected_annual_shipments": 52,
        "special_instructions": "Maintain active temperature logging 15-25°C. ADR certified haulage to Rotterdam, IMDG Code Class 9 ocean transport."
    }
    
    prompt = f"""
    Extract normalized parameters from this freight requirement:
    {json.dumps(requirement, indent=2)}
    
    Parameters to extract:
    - transport_modes_needed (Array[String])
    - is_hazmat (Boolean)
    - requires_temperature_control (Boolean)
    - is_oversized (Boolean)
    - requires_special_handling (Boolean)
    - estimated_transit_days (Number)
    - origin_country_code (String)
    - destination_country_code (String)
    """
    
    normalized_meta = call_groq_llm(prompt, model='openai/gpt-oss-20b')
    
    return {
        "raw_requirement": requirement,
        "normalized_meta": normalized_meta
    }

@test
def test_output(output, *args) -> None:
    assert output is not None, 'Freight requirement output is None'
    assert 'raw_requirement' in output, 'Missing raw_requirement in output'
    assert output['raw_requirement']['cargo_weight_kg'] == 14500, 'Weight mismatch'
