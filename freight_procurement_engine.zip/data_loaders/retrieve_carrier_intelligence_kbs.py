from typing import Dict, Any, List

if 'data_loader' not in globals():
    from mage_ai.data_preparation.decorators import data_loader
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test

@data_loader
def load_carrier_intelligence_kbs(*args, **kwargs) -> Dict[str, Any]:
    # 1. Rate Cards (Ocean base TEU, BAF, CAF, reefer surcharge, hazmat surcharge, terminal handling)
    kb_rate_cards = [
        {"carrier": "Maersk Line", "ocean_base_teu": 2450, "reefer_surcharge": 450, "hazmat_surcharge": 750, "thc_origin": 220, "thc_dest": 190, "drayage_per_km": 2.40, "total_sample_quote": 4350, "score": 0.94},
        {"carrier": "MSC Mediterranean Shipping", "ocean_base_teu": 2300, "reefer_surcharge": 400, "hazmat_surcharge": 700, "thc_origin": 210, "thc_dest": 180, "drayage_per_km": 2.30, "total_sample_quote": 4080, "score": 0.96},
        {"carrier": "CMA CGM Group", "ocean_base_teu": 2380, "reefer_surcharge": 420, "hazmat_surcharge": 720, "thc_origin": 215, "thc_dest": 185, "drayage_per_km": 2.35, "total_sample_quote": 4210, "score": 0.91},
        {"carrier": "Hapag-Lloyd", "ocean_base_teu": 2520, "reefer_surcharge": 480, "hazmat_surcharge": 800, "thc_origin": 230, "thc_dest": 200, "drayage_per_km": 2.50, "total_sample_quote": 4530, "score": 0.88},
        {"carrier": "Kuehne+Nagel", "ocean_base_teu": 2490, "reefer_surcharge": 440, "hazmat_surcharge": 760, "thc_origin": 225, "thc_dest": 195, "drayage_per_km": 2.45, "total_sample_quote": 4410, "score": 0.89},
        {"carrier": "DHL Global Forwarding", "ocean_base_teu": 2550, "reefer_surcharge": 460, "hazmat_surcharge": 780, "thc_origin": 235, "thc_dest": 205, "drayage_per_km": 2.55, "total_sample_quote": 4580, "score": 0.85},
        {"carrier": "DSV Panalpina", "ocean_base_teu": 2600, "reefer_surcharge": 470, "hazmat_surcharge": 810, "thc_origin": 240, "thc_dest": 210, "drayage_per_km": 2.60, "total_sample_quote": 4680, "score": 0.82},
        {"carrier": "DB Schenker", "ocean_base_teu": 2650, "reefer_surcharge": 490, "hazmat_surcharge": 830, "thc_origin": 245, "thc_dest": 215, "drayage_per_km": 2.65, "total_sample_quote": 4780, "score": 0.79}
    ]
    
    # 2. Performance (On-time %, claims ratio %, temperature compliance %, dwell time)
    kb_performance = [
        {"carrier": "Maersk Line", "on_time_pct": 94.2, "claims_ratio_pct": 0.12, "reefer_temp_compliance_pct": 99.4, "avg_port_dwell_days": 2.1, "score": 0.95},
        {"carrier": "Hapag-Lloyd", "on_time_pct": 93.8, "claims_ratio_pct": 0.15, "reefer_temp_compliance_pct": 99.1, "avg_port_dwell_days": 2.3, "score": 0.92},
        {"carrier": "Kuehne+Nagel", "on_time_pct": 92.5, "claims_ratio_pct": 0.18, "reefer_temp_compliance_pct": 98.7, "avg_port_dwell_days": 2.4, "score": 0.90},
        {"carrier": "MSC Mediterranean Shipping", "on_time_pct": 90.8, "claims_ratio_pct": 0.22, "reefer_temp_compliance_pct": 97.9, "avg_port_dwell_days": 2.8, "score": 0.88},
        {"carrier": "CMA CGM Group", "on_time_pct": 89.5, "claims_ratio_pct": 0.25, "reefer_temp_compliance_pct": 97.2, "avg_port_dwell_days": 3.0, "score": 0.86},
        {"carrier": "DHL Global Forwarding", "on_time_pct": 88.0, "claims_ratio_pct": 0.28, "reefer_temp_compliance_pct": 96.8, "avg_port_dwell_days": 3.2, "score": 0.84},
        {"carrier": "DSV Panalpina", "on_time_pct": 86.4, "claims_ratio_pct": 0.32, "reefer_temp_compliance_pct": 95.9, "avg_port_dwell_days": 3.5, "score": 0.81},
        {"carrier": "DB Schenker", "on_time_pct": 84.1, "claims_ratio_pct": 0.38, "reefer_temp_compliance_pct": 94.5, "avg_port_dwell_days": 3.9, "score": 0.77}
    ]
    
    # 3. Contracts (MSA provisions, liability caps, cargo value indemnity, jurisdiction)
    kb_contracts = [
        {"carrier": "Maersk Line", "standard_msa": "Standard BIMCO / Maersk terms, $2/kg statutory cap with negotiable value declaration, Rotterdam arbitration", "score": 0.92},
        {"carrier": "Kuehne+Nagel", "standard_msa": "Comprehensive 3PL Global MSA, tailored battery transport indemnification, London Maritime arbitration", "score": 0.94},
        {"carrier": "CMA CGM Group", "standard_msa": "Standard Ocean B/L conditions, Hague-Visby liability limits, Paris / Marseille jurisdiction", "score": 0.88},
        {"carrier": "MSC Mediterranean Shipping", "standard_msa": "Geneva MSA, strict force majeure definitions, English law dispute clause", "score": 0.86},
        {"carrier": "Hapag-Lloyd", "standard_msa": "Hamburg rules alignment, mutual SLA penalties clause, German commercial court jurisdiction", "score": 0.90},
        {"carrier": "DHL Global Forwarding", "standard_msa": "Standard FIATA multimodal B/L, DHL Trading Conditions 2024", "score": 0.85},
        {"carrier": "DSV Panalpina", "standard_msa": "DSV General Freight Terms, standard demurrage thresholds", "score": 0.83},
        {"carrier": "DB Schenker", "standard_msa": "German Freight Forwarders Terms (ADSp), standard risk caps", "score": 0.80}
    ]
    
    # 4. Compliance (Certifications: AEO, C-TPAT, ISO, ADR, IMDG Class 9)
    kb_compliance = [
        {"carrier": "Maersk Line", "certifications": ["AEO Full", "C-TPAT Tier 3", "ISO 9001", "ISO 14001", "IMDG Class 9 Certified", "SmartWay"], "score": 0.98},
        {"carrier": "Hapag-Lloyd", "certifications": ["AEO Full", "C-TPAT Tier 3", "ISO 9001", "ISO 14001", "IMDG Class 9 Certified"], "score": 0.96},
        {"carrier": "Kuehne+Nagel", "certifications": ["AEO Full", "C-TPAT Tier 3", "ISO 9001", "ISO 14001", "ADR / ATP Certified"], "score": 0.97},
        {"carrier": "MSC Mediterranean Shipping", "certifications": ["AEO Full", "C-TPAT Tier 2", "ISO 9001", "IMDG Class 9 Certified"], "score": 0.93},
        {"carrier": "CMA CGM Group", "certifications": ["AEO Full", "C-TPAT Tier 2", "ISO 9001", "ISO 14001", "IMDG Certified"], "score": 0.92},
        {"carrier": "DHL Global Forwarding", "certifications": ["AEO Full", "C-TPAT Tier 2", "ISO 9001", "ADR Certified"], "score": 0.89},
        {"carrier": "DSV Panalpina", "certifications": ["AEO Standard", "ISO 9001", "ADR Certified"], "score": 0.85},
        {"carrier": "DB Schenker", "certifications": ["AEO Standard", "ISO 9001", "ADR Certified"], "score": 0.84}
    ]
    
    # 5. Market Rates (Drewry, Xeneta, SCFI Benchmarks)
    kb_market_rates = [
        {"route": "Rotterdam to Shanghai", "benchmark_spot_rate": 2250, "benchmark_contract_rate": 2400, "scfi_index": 2180, "reefer_premium_avg": 420, "hazmat_premium_avg": 730, "fuel_baf_current": 580, "score": 0.95}
    ]
    
    # 6. Financials (D&B PAYDEX, Altman Z-Score, S&P Credit Rating)
    kb_financials = [
        {"carrier": "Maersk Line", "paydex": 82, "altman_z": 3.45, "sp_rating": "BBB+", "solvency_ratio": 0.62, "score": 0.93},
        {"carrier": "Hapag-Lloyd", "paydex": 84, "altman_z": 3.60, "sp_rating": "BBB+", "solvency_ratio": 0.65, "score": 0.95},
        {"carrier": "Kuehne+Nagel", "paydex": 86, "altman_z": 3.85, "sp_rating": "A-", "solvency_ratio": 0.58, "score": 0.97},
        {"carrier": "CMA CGM Group", "paydex": 78, "altman_z": 2.85, "sp_rating": "BBB-", "solvency_ratio": 0.52, "score": 0.86},
        {"carrier": "MSC Mediterranean Shipping", "paydex": 80, "altman_z": 3.10, "sp_rating": "Private (Strong)", "solvency_ratio": 0.60, "score": 0.89},
        {"carrier": "DHL Global Forwarding", "paydex": 83, "altman_z": 3.50, "sp_rating": "A", "solvency_ratio": 0.59, "score": 0.92},
        {"carrier": "DSV Panalpina", "paydex": 79, "altman_z": 3.05, "sp_rating": "BBB", "solvency_ratio": 0.54, "score": 0.87},
        {"carrier": "DB Schenker", "paydex": 76, "altman_z": 2.75, "sp_rating": "BBB-", "solvency_ratio": 0.49, "score": 0.82}
    ]
    
    return {
        "kb_rate_cards": kb_rate_cards,
        "kb_performance": kb_performance,
        "kb_contracts": kb_contracts,
        "kb_compliance": kb_compliance,
        "kb_market_rates": kb_market_rates,
        "kb_financials": kb_financials
    }

@test
def test_output(output, *args) -> None:
    assert output is not None, 'Intelligence KBs output is None'
    assert len(output['kb_rate_cards']) >= 8, 'Must have at least 8 carrier rate cards'
    assert len(output['kb_performance']) >= 8, 'Must have at least 8 performance profiles'
