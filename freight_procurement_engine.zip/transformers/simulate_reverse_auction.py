import json
import random
import os
from typing import Dict, Any, List

if 'transformer' not in globals():
    from mage_ai.data_preparation.decorators import transformer
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test

def calculate_should_cost(master_spec: dict) -> dict:
    cargo = master_spec.get('cargo', {})
    legs = master_spec.get('legs', [])
    
    # Distance and transit
    road_km = sum(l.get('distance_km', 0) for l in legs if l.get('mode') == 'road')
    sea_km = sum(l.get('distance_km', 0) for l in legs if l.get('mode') == 'sea')
    
    # Fuel cost model (diesel + marine low-sulfur bunker)
    fuel_road = (road_km / 3.5) * 1.65
    fuel_sea = 1120.0  # Apportioned TEU marine bunker BAF
    total_fuel = fuel_road + fuel_sea
    
    # Labor model (driver labor + vessel crew allocation)
    driving_hours = road_km / 65.0
    labor_road = driving_hours * 38.0
    labor_sea = 450.0
    total_labor = labor_road + labor_sea
    
    # Equipment depreciation & terminal handling
    equipment = 320.0
    
    # Marine Cargo Insurance (ad valorem on 14500kg battery cargo)
    cargo_value_est = 14500 * 22.0
    insurance = cargo_value_est * 0.0022
    
    # Accessorials: Reefer active power + Hazmat Class 9 surcharge
    accessorials = 420.0 + 680.0
    
    subtotal = total_fuel + total_labor + equipment + insurance + accessorials
    overhead = subtotal * 0.15
    base_margin = subtotal * 0.12
    should_cost = subtotal + overhead + base_margin
    
    reserve_price = should_cost * 1.15
    
    return {
        'should_cost': round(should_cost, 2),
        'reserve_price': round(reserve_price, 2),
        'breakdown': {
            'fuel': round(total_fuel, 2),
            'labor': round(total_labor, 2),
            'equipment': round(equipment, 2),
            'insurance': round(insurance, 2),
            'accessorials': round(accessorials, 2),
            'overhead': round(overhead, 2),
            'margin': round(base_margin, 2)
        }
    }

@transformer
def transform_simulate_reverse_auction(qual_data: Dict[str, Any], *args, **kwargs) -> Dict[str, Any]:
    """
    Game-Theoretic Bertrand Reverse Auction Simulation Loop:
    Simulates up to 5 rounds of price competition among qualified carriers.
    """
    master_spec = qual_data['master_spec']
    qualified_pool = qual_data['qualified_pool']
    
    should_cost_data = calculate_should_cost(master_spec)
    should_cost = should_cost_data['should_cost']
    reserve_price = should_cost_data['reserve_price']
    
    # Carrier profiles for Bertrand game theory
    carrier_profiles = []
    random.seed(42)
    for q in qualified_pool:
        base_bid = q.get('base_quote', should_cost * 1.18)
        carrier_profiles.append({
            'carrier_name': q['carrier_name'],
            'initial_bid': base_bid,
            'current_bid': base_bid,
            'capacity_utilization': random.uniform(0.65, 0.85),
            'backlog_ratio': random.uniform(0.40, 0.70),
            'relationship_score': random.uniform(7.0, 9.5),
            'qualification_score': q['total_score'],
            'status': q['status']
        })
        
    auction_history = []
    converged = False
    max_rounds = 5
    best_bid = float('inf')
    winning_carrier = None
    
    for round_num in range(1, max_rounds + 1):
        round_bids = []
        for cp in carrier_profiles:
            # Aggressiveness formula based on capacity & round progression
            cap_factor = 1.0 - cp['capacity_utilization']
            backlog_factor = 1.0 - (cp['backlog_ratio'] * 0.4)
            round_pressure = min(round_num * 0.07, 0.32)
            
            aggressiveness = (cap_factor * 0.35 + backlog_factor * 0.25 + round_pressure * 0.40)
            
            # Concession calculation
            discount_pct = aggressiveness * (0.04 + (round_num * 0.015))
            new_bid = cp['current_bid'] * (1.0 - discount_pct)
            
            # Floor boundary (carrier will not bid below should_cost * 1.015)
            carrier_cost_floor = should_cost * 1.015
            new_bid = max(carrier_cost_floor, new_bid)
            
            cp['current_bid'] = round(new_bid, 2)
            round_bids.append({
                'carrier': cp['carrier_name'],
                'bid_usd': cp['current_bid'],
                'aggressiveness': round(aggressiveness, 3),
                'discount_applied_pct': round(discount_pct * 100, 2),
                'qualification_score': cp['qualification_score'],
                'status': cp['status']
            })
            
        round_bids.sort(key=lambda x: x['bid_usd'])
        current_best = round_bids[0]['bid_usd']
        current_winner = round_bids[0]['carrier']
        
        # Calculate spread between 1st and 2nd or last
        spread_pct = round(((round_bids[-1]['bid_usd'] - round_bids[0]['bid_usd']) / round_bids[0]['bid_usd']) * 100, 2)
        top2_spread_pct = round(((round_bids[1]['bid_usd'] - round_bids[0]['bid_usd']) / round_bids[0]['bid_usd']) * 100, 2) if len(round_bids) > 1 else 0.0
        
        auction_history.append({
            'round': round_num,
            'bids': round_bids,
            'best_bid': current_best,
            'best_carrier': current_winner,
            'spread_pct': spread_pct,
            'top2_spread_pct': top2_spread_pct
        })
        
        best_bid = current_best
        winning_carrier = current_winner
        
        # Convergence criterion: top-2 spread < 4.0% or price <= should_cost * 1.03
        if top2_spread_pct < 4.0 or best_bid <= (should_cost * 1.03):
            converged = True
            break
            
    final_round = auction_history[-1]
    
    return {
        'master_spec': master_spec,
        'should_cost_data': should_cost_data,
        'auction_history': auction_history,
        'total_rounds': len(auction_history),
        'converged': converged,
        'best_bid_usd': best_bid,
        'winning_carrier': winning_carrier,
        'final_bids': final_round['bids'],
        'top_finalists': final_round['bids'][:3]
    }

@test
def test_output(output, *args) -> None:
    assert output is not None, 'Auction output is None'
    assert output['total_rounds'] >= 1, 'Must execute at least 2 auction rounds'
    assert output['best_bid_usd'] > 0, 'Winning bid must be positive'
