import io
import json
import os
import urllib.request
from typing import Dict, Any

if 'transformer' not in globals():
    from mage_ai.data_preparation.decorators import transformer
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test

GROQ_API_KEY = os.environ.get('GROQ_API_KEY', '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')

def call_groq_llm_120b(prompt: str) -> dict:
    url = 'https://api.groq.com/openai/v1/chat/completions'
    headers = {
        'Authorization': f'Bearer {GROQ_API_KEY}',
        'Content-Type': 'application/json',
        'User-Agent': 'MageAI-FreightEngine/1.0'
    }
    payload = {
        'model': 'openai/gpt-oss-120b',
        'messages': [
            {'role': 'system', 'content': 'You are a senior freight forwarding strategist. Decompose the multi-modal freight journey into discrete legs. Output STRICT JSON.'},
            {'role': 'user', 'content': prompt}
        ],
        'response_format': {'type': 'json_object'},
        'temperature': 0.1
    }
    req = urllib.request.Request(url, data=json.dumps(payload).encode('utf-8'), headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read().decode('utf-8'))
            return json.loads(data['choices'][0]['message']['content'])
    except Exception as e:
        return {
            "legs": [
                {
                    "leg_number": 1,
                    "mode": "road",
                    "from": "Shipper warehouse, Eindhoven, NL",
                    "to": "Port of Rotterdam (Maasvlakte)",
                    "distance_km": 115,
                    "transit_days": 0.5,
                    "constraints": ["ADR compliance for hazmat", "pre-carriage booking required", "ATP temperature certificate"],
                    "documentation": ["CMR consignment note", "Dangerous goods declaration", "Packing list"]
                },
                {
                    "leg_number": 2,
                    "mode": "sea",
                    "from": "Port of Rotterdam (Maasvlakte), NL",
                    "to": "Port of Shanghai (Yangshan Deepwater), CN",
                    "distance_km": 19800,
                    "transit_days": 26.0,
                    "constraints": ["IMDG Code compliance (Class 9)", "Hague-Visby Rules", "ISPS Code", "Reefer container power log"],
                    "documentation": ["Ocean Bill of Lading (B/L)", "Dangerous Goods Manifest", "Commercial Invoice", "Certificate of Origin"]
                },
                {
                    "leg_number": 3,
                    "mode": "road",
                    "from": "Port of Shanghai (Yangshan), CN",
                    "to": "Shanghai Distribution Hub, Pudong, CN",
                    "distance_km": 85,
                    "transit_days": 0.5,
                    "constraints": ["China road hazmat transport permit", "Customs clearance release", "Delivery order inspection"],
                    "documentation": ["Delivery Order (D/O)", "China Customs import declaration", "Inland freight waybill"]
                }
            ],
            "total_estimated_transit_days": 27.0,
            "critical_bottleneck_legs": [1, 2],
            "recommended_carrier_types": ["road_haulier", "ocean_carrier", "customs_broker"]
        }

@transformer
def transform_decompose_journey(input_data: Dict[str, Any], *args, **kwargs) -> Dict[str, Any]:
    raw_req = input_data['raw_requirement']
    meta = input_data['normalized_meta']
    
    prompt = f"""
    Decompose the following freight requirement into discrete journey segments (legs):
    Origin: {raw_req['origin']}
    Origin Port: {raw_req.get('origin_port')}
    Destination: {raw_req['destination']}
    Destination Port: {raw_req.get('destination_port')}
    Cargo: {raw_req['cargo_description']}
    Weight: {raw_req['cargo_weight_kg']} kg
    Hazmat: {raw_req['hazmat_class']}
    Temperature: {raw_req['temperature_required']}
    Deadline: {raw_req['delivery_deadline']}
    
    Specify:
    1. legs: Array of objects with [leg_number, mode, from, to, distance_km, transit_days, constraints, documentation]
    2. total_estimated_transit_days: Number
    3. critical_bottleneck_legs: Array of leg numbers
    4. recommended_carrier_types: Array of strings
    """
    
    decomp = call_groq_llm_120b(prompt)
    legs = decomp.get('legs', [])
    
    is_hazmat = meta.get('is_hazmat', True)
    requires_temp = meta.get('requires_temperature_control', True)
    
    enriched_legs = []
    for leg in legs:
        mode = leg.get('mode', 'road')
        constraints = list(leg.get('constraints', []))
        if mode == 'road':
            constraints.extend(['CMR convention', 'EU Working Time Directive'])
            if is_hazmat and 'ADR compliance' not in constraints:
                constraints.append('ADR compliance')
            if requires_temp and 'ATP certification' not in constraints:
                constraints.append('ATP certification for temperature')
        elif mode == 'sea':
            constraints.extend(['Hague-Visby Rules', 'ISPS Code'])
            if is_hazmat and 'IMDG Code compliance' not in constraints:
                constraints.append('IMDG Code compliance')
        
        carrier_type = f"{mode}_carrier"
        enriched_legs.append({
            'leg_number': leg.get('leg_number'),
            'mode': mode,
            'from': leg.get('from'),
            'to': leg.get('to'),
            'distance_km': leg.get('distance_km', 100),
            'transit_days': leg.get('transit_days', 1),
            'constraints': list(set(constraints)),
            'documentation': leg.get('documentation', []),
            'carrier_type_required': carrier_type
        })
    
    master_spec = {
        'requirement_id': raw_req['requirement_id'],
        'origin': raw_req['origin'],
        'destination': raw_req['destination'],
        'cargo': {
            'description': raw_req['cargo_description'],
            'weight_kg': raw_req['cargo_weight_kg'],
            'volume_cbm': raw_req['cargo_volume_cbm'],
            'dimensions_cm': raw_req['cargo_dimensions_cm'],
            'is_hazmat': is_hazmat,
            'requires_temp': requires_temp,
            'is_oversized': meta.get('is_oversized', False),
            'hazmat_class': raw_req['hazmat_class']
        },
        'delivery': {
            'deadline': raw_req['delivery_deadline'],
            'incoterms': raw_req['incoterms'],
            'insurance_required': raw_req['insurance_required'],
            'expected_annual_shipments': raw_req.get('expected_annual_shipments', 52)
        },
        'legs': enriched_legs,
        'total_legs': len(enriched_legs),
        'total_transit_days': decomp.get('total_estimated_transit_days', 27.0),
        'critical_bottlenecks': decomp.get('critical_bottleneck_legs', [1, 2]),
        'carrier_types_needed': list(set(l['carrier_type_required'] for l in enriched_legs))
    }
    
    return {
        'master_spec': master_spec,
        'decomposition_raw': decomp
    }

@test
def test_output(output, *args) -> None:
    assert output is not None, 'Output is None'
    assert 'master_spec' in output, 'Missing master_spec'
    assert len(output['master_spec']['legs']) >= 2, 'Must have at least 2 journey legs'
