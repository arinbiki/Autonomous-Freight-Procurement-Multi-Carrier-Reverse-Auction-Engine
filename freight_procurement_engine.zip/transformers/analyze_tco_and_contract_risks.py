import json
import math
import random
from typing import Dict, Any, List

if 'transformer' not in globals():
    from mage_ai.data_preparation.decorators import transformer
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test

@transformer
def transform_analyze_tco(auction_data: Dict[str, Any], *args, **kwargs) -> Dict[str, Any]:
    master_spec = auction_data['master_spec']
    best_bid_usd = auction_data['best_bid_usd']
    annual_shipments = master_spec.get('delivery', {}).get('expected_annual_shipments', 52)
    
    # 1. 3-Year TCO Projection with Escalations
    # Fuel: 6% / yr (40% weight), Labor: 4% / yr (30% weight), General: 2.5% / yr (30% weight)
    fuel_esc = 0.06
    labor_esc = 0.04
    gen_esc = 0.025
    discount_rate = 0.08
    
    yearly_costs = []
    cumulative = 0.0
    for year in range(1, 4):
        esc_factor = (
            ((1.0 + fuel_esc) ** (year - 1) * 0.40) +
            ((1.0 + labor_esc) ** (year - 1) * 0.30) +
            ((1.0 + gen_esc) ** (year - 1) * 0.30)
        )
        annual_cost = best_bid_usd * annual_shipments * esc_factor
        cumulative += annual_cost
        npv_year = annual_cost / ((1.0 + discount_rate) ** year)
        yearly_costs.append({
            'year': year,
            'escalation_factor': round(esc_factor, 4),
            'annual_cost_usd': round(annual_cost, 2),
            'cumulative_cost_usd': round(cumulative, 2),
            'discounted_npv_usd': round(npv_year, 2)
        })
        
    tco_3yr_total = round(cumulative, 2)
    npv_3yr = round(sum(y['discounted_npv_usd'] for y in yearly_costs), 2)
    
    # 2. Tornado Sensitivity Analysis (Fuel +-20%, FX +-10%, Volume +-15%)
    tornado = [
        {'variable': 'Fuel Price Shock (+20%)', 'delta_pct': 8.0, 'cost_usd': round(tco_3yr_total * 1.08, 2)},
        {'variable': 'Fuel Price Decline (-20%)', 'delta_pct': -8.0, 'cost_usd': round(tco_3yr_total * 0.92, 2)},
        {'variable': 'EUR/USD FX Depreciation (+10%)', 'delta_pct': 5.0, 'cost_usd': round(tco_3yr_total * 1.05, 2)},
        {'variable': 'EUR/USD FX Appreciation (-10%)', 'delta_pct': -5.0, 'cost_usd': round(tco_3yr_total * 0.95, 2)},
        {'variable': 'Annual Cargo Volume Expansion (+15%)', 'delta_pct': 15.0, 'cost_usd': round(tco_3yr_total * 1.15, 2)},
        {'variable': 'Annual Cargo Volume Contraction (-15%)', 'delta_pct': -15.0, 'cost_usd': round(tco_3yr_total * 0.85, 2)}
    ]
    tornado.sort(key=lambda x: abs(x['delta_pct']), reverse=True)
    
    # 3. Monte Carlo Simulation (1,000 iterations)
    random.seed(42)
    sim_runs = []
    for _ in range(1000):
        fuel_var = random.gauss(0.0, 0.08)
        fx_var = random.gauss(0.0, 0.05)
        vol_var = random.gauss(0.0, 0.10)
        demand_spike = 1.18 if random.random() < 0.05 else 1.0
        
        factor = (1.0 + fuel_var * 0.40) * (1.0 + fx_var * 0.30) * (1.0 + vol_var) * demand_spike
        sim_runs.append(tco_3yr_total * factor)
        
    sim_runs.sort()
    p10 = round(sim_runs[100], 2)
    p50 = round(sim_runs[500], 2)
    p90 = round(sim_runs[900], 2)
    mean_val = round(sum(sim_runs) / len(sim_runs), 2)
    std_dev = round(math.sqrt(sum((x - mean_val) ** 2 for x in sim_runs) / len(sim_runs)), 2)
    p90_risk_premium_pct = round(((p90 - tco_3yr_total) / tco_3yr_total) * 100, 2)
    
    monte_carlo = {
        'p10': p10,
        'p50': p50,
        'p90': p90,
        'mean': mean_val,
        'std_dev': std_dev,
        'p90_risk_premium_pct': p90_risk_premium_pct
    }
    
    # 4. Contract Risk Assessment & Legal Redlines
    redlines = [
        {
            'clause_title': 'Section 14.2 — Carrier Liability Limitations',
            'original_clause': 'Carrier liability for cargo loss or damage shall be strictly limited to SDR 2.00 per gross kilogram in accordance with Hague-Visby rules.',
            'proposed_redline': 'Carrier liability for Lithium-Ion Battery Storage cargo shall be ad valorem capped at agreed cargo replacement value of EUR 319,000 per container shipment, supported by Carrier primary transit insurance policy.',
            'rationale': 'High-value hazardous cargo exceeds standard statutory weight caps; protects balance sheet against thermal runaway loss.'
        },
        {
            'clause_title': 'Section 8.4 — Reefer Temperature Telemetry & SLA Penalties',
            'original_clause': 'Carrier shall make commercially reasonable efforts to maintain set point temperatures.',
            'proposed_redline': 'Carrier warrants continuous temperature maintenance within 15-25°C with mandatory active cellular/satellite IoT data loggers. Temperature excursion > 4 consecutive hours triggers liquidated damages of 25% freight refund plus survey inspection costs.',
            'rationale': 'Lithium-ion cells degrade if sustained heat threshold is breached.'
        }
    ]
    
    return {
        'master_spec': master_spec,
        'auction_data': auction_data,
        'tco_3yr': {
            'total_usd': tco_3yr_total,
            'npv_usd': npv_3yr,
            'annual_breakdown': yearly_costs,
            'sensitivity_tornado': tornado
        },
        'monte_carlo': monte_carlo,
        'contract_redlines': redlines
    }

@test
def test_output(output, *args) -> None:
    assert output is not None, 'TCO output is None'
    assert output['tco_3yr']['total_usd'] > 0, 'TCO total must be positive'
    assert output['monte_carlo']['p90'] > output['monte_carlo']['p10'], 'P90 must exceed P10'
