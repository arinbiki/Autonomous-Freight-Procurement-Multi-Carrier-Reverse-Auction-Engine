import json
from typing import Dict, Any, List

if 'transformer' not in globals():
    from mage_ai.data_preparation.decorators import transformer
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test

@transformer
def transform_execute_rrf(journey_data: Dict[str, Any], kb_data: Dict[str, Any], *args, **kwargs) -> Dict[str, Any]:
    """
    6-source Reciprocal Rank Fusion (RRF) with Domain-Specific Weights:
    RRF_Score = SUM( weight[source] / (K + rank) )
    K = 60
    """
    master_spec = journey_data['master_spec']
    K = 60
    
    weights = {
        'rates':        0.25,
        'performance':  0.25,
        'contracts':    0.20,
        'compliance':   0.15,
        'market':       0.10,
        'financials':   0.05
    }
    
    all_carriers = {}
    
    sources = [
        ('rates', kb_data.get('kb_rate_cards', [])),
        ('performance', kb_data.get('kb_performance', [])),
        ('contracts', kb_data.get('kb_contracts', [])),
        ('compliance', kb_data.get('kb_compliance', [])),
        ('financials', kb_data.get('kb_financials', []))
    ]
    
    for source_name, doc_list in sources:
        for rank, doc in enumerate(doc_list, 1):
            carrier_name = doc.get('carrier')
            if not carrier_name:
                continue
            
            if carrier_name not in all_carriers:
                all_carriers[carrier_name] = {
                    'carrier_name': carrier_name,
                    'rrf_score': 0.0,
                    'appears_in': [],
                    'ranks': {},
                    'data_by_source': {}
                }
            
            w = weights.get(source_name, 0.1)
            rrf_contrib = w / (K + rank)
            all_carriers[carrier_name]['rrf_score'] += rrf_contrib
            all_carriers[carrier_name]['appears_in'].append(source_name)
            all_carriers[carrier_name]['ranks'][source_name] = rank
            all_carriers[carrier_name]['data_by_source'][source_name] = doc
            
    # Add market benchmark score contribution to top performers
    market_ref = kb_data.get('kb_market_rates', [{}])[0]
    for c_name, c_obj in all_carriers.items():
        c_obj['market_benchmark'] = market_ref
        c_obj['rrf_score'] = round(c_obj['rrf_score'] * 1000, 4)
        
    ranked = sorted(all_carriers.values(), key=lambda x: x['rrf_score'], reverse=True)
    
    # Hard constraint check: IMDG Class 9 or ADR capabilities
    filtered = []
    for c in ranked:
        comp_doc = c['data_by_source'].get('compliance', {})
        certs = comp_doc.get('certifications', [])
        has_hazmat_cert = any('IMDG' in cert or 'ADR' in cert for cert in certs)
        c['passes_hard_constraints'] = has_hazmat_cert
        if has_hazmat_cert:
            filtered.append(c)
            
    pool_size = len(filtered)
    sufficiency = 'sufficient' if pool_size >= 3 else 'marginal' if pool_size >= 1 else 'insufficient'
    
    return {
        'master_spec': master_spec,
        'carrier_pool': filtered[:8],
        'pool_size': pool_size,
        'sufficiency': sufficiency,
        'top_carrier': filtered[0]['carrier_name'] if filtered else None,
        'top_rrf_score': filtered[0]['rrf_score'] if filtered else 0
    }

@test
def test_output(output, *args) -> None:
    assert output is not None, 'RRF output is None'
    assert output['pool_size'] >= 3, 'Carrier pool must have at least 3 carriers'
    assert output['sufficiency'] == 'sufficient', 'Pool sufficiency must be sufficient'
