import json
from typing import Dict, Any, List

if 'transformer' not in globals():
    from mage_ai.data_preparation.decorators import transformer
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test

@transformer
def transform_generate_batna(tco_data: Dict[str, Any], *args, **kwargs) -> Dict[str, Any]:
    master_spec = tco_data['master_spec']
    auction_data = tco_data['auction_data']
    winning_bid = auction_data['best_bid_usd']
    top_finalists = auction_data['top_finalists']
    
    # Calculate Bilateral BATNA
    # Our BATNA: 2nd best carrier quote with switching cost buffer vs spot market
    second_bid = top_finalists[1]['bid_usd'] if len(top_finalists) > 1 else winning_bid * 1.06
    our_batna_usd = round(second_bid * 1.025, 2)  # 2.5% switching cost tolerance
    
    # Carrier's estimated BATNA: minimum fixture rate to avoid idle vessel slot
    carrier_batna_usd = round(winning_bid * 0.88, 2)
    
    zopa_range = {
        'min_usd': carrier_batna_usd,
        'max_usd': our_batna_usd
    }
    
    # Negotiating Leverage Ratio
    leverage_ratio = round(our_batna_usd / carrier_batna_usd, 2)
    leverage_level = 'HIGH' if leverage_ratio >= 1.25 else 'MEDIUM' if leverage_ratio >= 1.05 else 'LOW'
    
    # 3-Scenario Decision Tree
    scenarios = {
        'best_case': {
            'scenario': 'Target Concession (Volume Commitment Anchoring)',
            'price_usd': round(winning_bid * 0.94, 2),
            'probability': 0.30,
            'terms': 'SLA guarantee + demurrage free time extended from 7 to 14 days'
        },
        'expected_case': {
            'scenario': 'Market Alignment (Balanced Agreement)',
            'price_usd': round(winning_bid * 0.97, 2),
            'probability': 0.50,
            'terms': '10 days demurrage free time + reefer telemetry data sharing'
        },
        'worst_case': {
            'scenario': 'Fixed Award (Current Reverse Auction Price)',
            'price_usd': round(winning_bid, 2),
            'probability': 0.20,
            'terms': 'Standard contract terms with warranty redlines'
        }
    }
    
    expected_value_usd = round(
        sum(s['price_usd'] * s['probability'] for s in scenarios.values()),
        2
    )
    
    playbook = {
        'opening_anchor_usd': round(winning_bid * 0.92, 2),
        'target_award_usd': round(winning_bid * 0.96, 2),
        'walk_away_ceiling_usd': our_batna_usd,
        'concession_ladder': [
            {'step': 1, 'offer_usd': round(winning_bid * 0.93, 2), 'ask': '14 days demurrage free time'},
            {'step': 2, 'offer_usd': round(winning_bid * 0.955, 2), 'ask': 'IoT temperature telemetry SLA warranty'},
            {'step': 3, 'offer_usd': round(winning_bid * 0.97, 2), 'ask': 'Final binding 3-year rate freeze with bunker clause'}
        ],
        'tactical_moves': [
            'Signal second-place carrier competitive proximity (spread is < 3%)',
            'Offer guaranteed 52 annual shipment volume commitment in exchange for ad valorem liability cap acceptance'
        ]
    }
    
    return {
        'master_spec': master_spec,
        'tco_data': tco_data,
        'batna_analysis': {
            'our_batna_usd': our_batna_usd,
            'carrier_batna_usd': carrier_batna_usd,
            'zopa_range': zopa_range,
            'leverage_ratio': leverage_ratio,
            'leverage_level': leverage_level
        },
        'scenario_tree': scenarios,
        'expected_value_usd': expected_value_usd,
        'negotiation_playbook': playbook
    }

@test
def test_output(output, *args) -> None:
    assert output is not None, 'BATNA output is None'
    assert output['batna_analysis']['leverage_ratio'] > 0, 'Leverage ratio must be positive'
