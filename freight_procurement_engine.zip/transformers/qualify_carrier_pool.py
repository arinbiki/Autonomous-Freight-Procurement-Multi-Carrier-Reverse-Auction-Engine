import json
import os
import urllib.request
from typing import Dict, Any, List

if 'transformer' not in globals():
    from mage_ai.data_preparation.decorators import transformer
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test

GROQ_API_KEY = os.environ.get('GROQ_API_KEY', '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')

def call_groq_llm_narrative(carrier_name: str, score_data: dict) -> str:
    url = 'https://api.groq.com/openai/v1/chat/completions'
    headers = {
        'Authorization': f'Bearer {GROQ_API_KEY}',
        'Content-Type': 'application/json',
        'User-Agent': 'MageAI-FreightEngine/1.0'
    }
    prompt = f"Generate a concise 2-sentence qualification summary for freight carrier {carrier_name} with qualification score {score_data['total_score']} ({score_data['status']})."
    payload = {
        'model': 'openai/gpt-oss-20b',
        'messages': [
            {'role': 'system', 'content': 'You are a corporate freight compliance auditor.'},
            {'role': 'user', 'content': prompt}
        ],
        'max_tokens': 120,
        'temperature': 0.2
    }
    req = urllib.request.Request(url, data=json.dumps(payload).encode('utf-8'), headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode('utf-8'))
            return data['choices'][0]['message']['content'].strip()
    except Exception:
        return f"{carrier_name} has achieved an audited qualification score of {score_data['total_score']} points. Status: {score_data['status']}, with validated safety and compliance records."

@transformer
def transform_qualify_carrier_pool(rrf_data: Dict[str, Any], *args, **kwargs) -> Dict[str, Any]:
    master_spec = rrf_data['master_spec']
    carrier_pool = rrf_data['carrier_pool']
    
    qualifications = []
    
    for carrier in carrier_pool:
        c_name = carrier['carrier_name']
        data = carrier.get('data_by_source', {})
        perf = data.get('performance', {})
        fin = data.get('financials', {})
        comp = data.get('compliance', {})
        rates = data.get('rates', {})
        
        # 1. Capacity score (0-100)
        # Based on schedule reliability and dwell times
        cap_score = min(100.0, perf.get('on_time_pct', 85) * 1.05)
        
        # 2. Safety score (0-100)
        # Low claims ratio and high temp compliance
        claims_ratio = perf.get('claims_ratio_pct', 0.2)
        temp_comp = perf.get('reefer_temp_compliance_pct', 98.0)
        safety_score = max(50.0, temp_comp - (claims_ratio * 30))
        
        # 3. Financial score (0-100)
        paydex = fin.get('paydex', 80)
        altman_z = fin.get('altman_z', 3.0)
        fin_score = min(100.0, (paydex * 0.8) + (altman_z * 8.0))
        
        # 4. Compliance score (0-100)
        certs = comp.get('certifications', [])
        comp_score = 95.0 if len(certs) >= 5 else 85.0 if len(certs) >= 3 else 70.0
        
        # 5. Geographic coverage score (0-100)
        geo_score = 92.0 if 'Maersk' in c_name or 'MSC' in c_name or 'Hapag' in c_name or 'CMA' in c_name else 88.0
        
        # Weighted composite score
        # Weights: capacity 0.30, safety 0.25, financial 0.20, compliance 0.15, geo 0.10
        total_score = round(
            cap_score * 0.30 +
            safety_score * 0.25 +
            fin_score * 0.20 +
            comp_score * 0.15 +
            geo_score * 0.10,
            2
        )
        
        status = 'QUALIFIED' if total_score >= 80.0 else 'CONDITIONAL' if total_score >= 65.0 else 'REJECTED'
        
        score_data = {
            'carrier_name': c_name,
            'total_score': total_score,
            'status': status,
            'breakdown': {
                'capacity': round(cap_score, 2),
                'safety': round(safety_score, 2),
                'financial': round(fin_score, 2),
                'compliance': round(comp_score, 2),
                'geo': round(geo_score, 2)
            },
            'base_quote': rates.get('total_sample_quote', 4300),
            'paydex': paydex,
            'on_time_pct': perf.get('on_time_pct', 90.0)
        }
        
        narrative = call_groq_llm_narrative(c_name, score_data)
        score_data['narrative'] = narrative
        qualifications.append(score_data)
        
    qualified_pool = [q for q in qualifications if q['status'] in ['QUALIFIED', 'CONDITIONAL']]
    qualified_pool.sort(key=lambda x: x['total_score'], reverse=True)
    
    return {
        'master_spec': master_spec,
        'qualified_pool': qualified_pool,
        'total_qualified': len(qualified_pool),
        'top_qualified_carrier': qualified_pool[0]['carrier_name'] if qualified_pool else None
    }

@test
def test_output(output, *args) -> None:
    assert output is not None, 'Qualification output is None'
    assert output['total_qualified'] >= 3, 'Must have at least 3 qualified carriers'
